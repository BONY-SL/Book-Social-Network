create function "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) returns boolean
    stable
    parallel safe
    cost 1
    language sql
RETURN (($1, ($1 + $2)) OVERLAPS ($3, $4));

comment on function "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) is 'intervals overlap?';

alter function "overlaps"(timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) owner to postgres;

